import REMS.TPH as TPH

TPH.getTemperature
TPH.getHumidity
TPH.getPressure
TPH.getDewPoint
TPH.writeToCSV