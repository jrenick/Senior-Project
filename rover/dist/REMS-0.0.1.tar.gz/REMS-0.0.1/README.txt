This library provides several simple Environmental Measurement calculations that is provided by the bme280
 adafruit temperature, humidity, and pressure sensor. There are other functions that provide other
calculations based off these measurements as well.